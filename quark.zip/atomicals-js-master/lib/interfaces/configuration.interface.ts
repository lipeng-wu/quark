
export interface ConfigurationInterface {
    electrumxWebsocketUrl: string;
}

export interface HydratedConfigurationInterface {
    electrumxWebsocketUrl: string
}