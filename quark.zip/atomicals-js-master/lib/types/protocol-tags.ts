export const ATOMICALS_PROTOCOL_ENVELOPE_ID = 'atom';
