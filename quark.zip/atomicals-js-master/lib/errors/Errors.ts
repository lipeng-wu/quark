export class InvalidNameError extends Error {
    constructor(m?: string) {
        super(m);
    }
}
 