 export interface CommandResultInterface {
    success: boolean;
    message?: string;
    stack?: any;
    data?: any;
    error?: any;
}
  